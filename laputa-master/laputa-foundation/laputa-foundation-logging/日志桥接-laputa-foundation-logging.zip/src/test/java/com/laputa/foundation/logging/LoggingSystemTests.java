package com.laputa.foundation.logging;

import org.junit.After;
import org.junit.Test;

/**
 * Tests for {@link LoggingSystem}.
 *
 * @author Andy Wilkinson
 */
public class LoggingSystemTests {

    @After
    public void clearSystemProperty() {
        System.clearProperty(LoggingSystem.SYSTEM_PROPERTY);
    }

    @Test
    public void loggingSystemCanBeDisabled() {
        System.setProperty(LoggingSystem.SYSTEM_PROPERTY, LoggingSystem.NONE);
        LoggingSystem loggingSystem = LoggingSystem.get(getClass().getClassLoader());
        //assertThat(loggingSystem).isInstanceOf(NoOpLoggingSystem.class);
        loggingSystem.getClass().toString();
    }

}