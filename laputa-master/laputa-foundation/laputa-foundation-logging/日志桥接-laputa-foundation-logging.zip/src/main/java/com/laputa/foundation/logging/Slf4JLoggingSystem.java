package com.laputa.foundation.logging;


import org.slf4j.bridge.SLF4JBridgeHandler;

import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;

/**
 * Abstract base class for {@link LoggingSystem} implementations that utilize SLF4J.
 *
 * @author Andy Wilkinson
 * @since 1.2.0
 */
public abstract class Slf4JLoggingSystem extends AbstractLoggingSystem {

    private static final String BRIDGE_HANDLER = "org.slf4j.bridge.SLF4JBridgeHandler";

    public Slf4JLoggingSystem(ClassLoader classLoader) {
        super(classLoader);
    }

    @Override
    public void beforeInitialize() {
        super.beforeInitialize();
        configureJdkLoggingBridgeHandler();
    }

    @Override
    public void cleanUp() {
        removeJdkLoggingBridgeHandler();
    }

    @Override
    protected void loadConfiguration(LoggingInitializationContext initializationContext,
                                     String location, LogFile logFile) {
        Assert.notNull(location, "Location must not be null");
        if (initializationContext != null) {
            applySystemProperties(initializationContext.getEnvironment(), logFile);
        }
    }

    private void configureJdkLoggingBridgeHandler() {
        try {
            if (isBridgeHandlerAvailable()) {
                removeJdkLoggingBridgeHandler();
                SLF4JBridgeHandler.install();
            }
        }
        catch (Throwable ex) {
            // Ignore. No java.util.logging bridge is installed.
        }
    }

    protected final boolean isBridgeHandlerAvailable() {
        return ClassUtils.isPresent(BRIDGE_HANDLER, getClassLoader());
    }

    private void removeJdkLoggingBridgeHandler() {
        try {
            if (isBridgeHandlerAvailable()) {
                try {
                    SLF4JBridgeHandler.removeHandlersForRootLogger();
                }
                catch (NoSuchMethodError ex) {
                    // Method missing in older versions of SLF4J like in JBoss AS 7.1
                    SLF4JBridgeHandler.uninstall();
                }
            }
        }
        catch (Throwable ex) {
            // Ignore and continue
        }
    }

}